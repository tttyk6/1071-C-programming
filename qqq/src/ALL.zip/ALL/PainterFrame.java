package ALL;


import java.awt.BorderLayout;

import javax.swing.JFrame;

	public class PainterFrame extends JFrame {
		
		private DrawPanel drawPanel;
		public PainterFrame() {
			super();
			drawPanel = new DrawPanel();
			add(drawPanel, BorderLayout.CENTER);
			
		}

	}
