package ALL;


public class test {
	public static void main(String[] args) {
		PainterFrame pframe =new PainterFrame(); //�s
		pframe.setSize(900, 800);
		pframe.setVisible(true);
	}

}
