package painter;

import java.awt.Color;
import java.awt.Graphics;

public class Vtri extends Shape{
	

	
	final int UpLeft =1; 
	final int UpRight =2;
	final int DownLeft =3;
	final int DownRight =4;
	private int type;
	

	public Vtri(int x1, int x2, int y1, int y2,int type, boolean filled, Color color) {
		super(x1, x2, y1, y2,filled, color);
		this.type = type;//////
		
	}
	
	public int getType()
	{
		return type;
	}
   public void draw(Graphics g) {
	   int tx1 =Math.min(x1, x2);
	   int ty1 =Math.min(y1, y2);
	   int tx4 =Math.max(x1, x2);
	   int ty4 =Math.max(y1, y2);
	   int tx2 = tx4;
	   int ty2 = ty1;
	   int tx3 = tx1;
	   int ty3 = ty4;
	   
	   int x[]=null;
	   int y[]=null;
	   
	   
	   switch(type) {
	   case UpLeft:
		   x = new int[] {tx1,tx3,tx4}; 
		   y = new int[] {ty1,ty3,ty4};
		   break;
	   case UpRight:
		   x = new int[] {tx2,tx3,tx4};
		   y = new int[] {ty2,ty3,ty4};
		   break;
	   case DownLeft:
		   x = new int[] {tx1,tx2,tx3};
		   y = new int[] {ty1,ty2,ty3};
		   break;
	   case DownRight:
	       x = new int[] {tx1,tx2,tx4};
	       y = new int[] {ty1,ty2,ty4};
	       break;
	   }
	   
	   if(filled) {
		   g.fillPolygon(x,y,3);
	   }else
	   {
		   g.drawPolygon(x,y,3);
	   }
	   
	  
	   
   } 
}
