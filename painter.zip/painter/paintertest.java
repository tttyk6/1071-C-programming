package painter;

public class paintertest {

	public static void main(String[] args) {
		Painterframe pframe =new Painterframe(); //�s
		pframe.setSize(900, 800);
		pframe.setVisible(true);
	}

}
