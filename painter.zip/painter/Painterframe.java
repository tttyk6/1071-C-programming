package painter;
import java.awt.BorderLayout;

import javax.swing.JFrame;

public class Painterframe extends JFrame {
	
	private DrawPanel drawPanel;
	public Painterframe(){
		super();
		
		drawPanel = new DrawPanel();
		add(drawPanel,BorderLayout.CENTER);
		}

}
